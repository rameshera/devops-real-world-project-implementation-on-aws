import Checkout from "./Checkout";

class CheckoutShipping extends Checkout {
  constructor() {
    super();
  }
}

module.exports = CheckoutShipping;
